require(methods)

setClass("Rephine",
         representation("list"))

